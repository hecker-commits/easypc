import os
import json
import ctypes
import tkinter as tk
from tkinter import filedialog

COMMANDS_FILE = "commands.json"
CONFIG_FILE = "config.json"
ADMIN_PASSWORD = "777888999000heckercommits"

if not os.path.exists(COMMANDS_FILE):
    with open(COMMANDS_FILE, "w") as f:
        json.dump({
            "open_settings": "settings",
            "open_explorer": "explorer",
            "open_notepad": "notepad",
            "change_wallpaper": "wall",
            "open_calc": "calc",
            "shutdown_pc": "shutdown /s /t 0",
            "restart_pc": "shutdown /r /t 0",
            "lock_pc": "rundll32.exe user32.dll,LockWorkStation",
            "logoff_pc": "shutdown /l",
            "taskmgr": "taskmgr",
            "cmd": "cmd",
            "powershell": "powershell",
            "controlpanel": "control",
            "device_manager": "devmgmt.msc",
            "msconfig": "msconfig",
            "regedit": "regedit",
            "clear_temp": "del /q/f/s %TEMP%\\*",
            "open_temp": "start %TEMP%",
            "ipconfig": "ipconfig",
            "ping_google": "ping google.com",
            "wifi_list": "netsh wlan show networks",
            "volume_mute": "nircmd.exe mutesysvolume 1",
            "volume_max": "nircmd.exe setsysvolume 65535",
            "open_msstore": "start ms-windows-store:",
            "open_calendar": "start outlookcal:",
            "open_camera": "start microsoft.windows.camera:",
            "open_mail": "start microsoft.windowscommunicationsapps:",
            "open_maps": "start bingmaps:"
        }, f, indent=4)

with open(COMMANDS_FILE, "r") as f:
    COMMANDS = json.load(f)

if not os.path.exists(CONFIG_FILE):
    with open(CONFIG_FILE, "w") as f:
        json.dump({"language": "EN"}, f)

with open(CONFIG_FILE, "r") as f:
    CONFIG = json.load(f)
LANG = CONFIG.get("language", "EN")

translations={
"EN":{"select_language":"Select your language: 1-English 2-Romana 3-Deutsch 4-Español > ",
"command_not_found":"Command does not exist.","help_text":"Available commands: help, admin, exit, cls, !changelanguage",
"invalid_password":"Invalid password!","access_granted":"Access Granted! Use !commandadd to add commands or !exit to leave.",
"no_file_selected":"No file selected!","command_added":"Command '{name}' was added successfully!",
"enter_command_name":"Enter the name of the new command:","welcome_admin":"Welcome Admin!","enter_password":"Please enter your admin password/license: ",
"language_changed":"Language changed successfully!","categories":{"System":"System Commands","Utilities":"Utilities","Apps":"Applications"}},
"RO":{"select_language":"Selectați limba: 1-English 2-Romana 3-Deutsch 4-Español > ",
"command_not_found":"Comanda nu există.","help_text":"Comenzi disponibile: help, admin, exit, cls, !changelanguage",
"invalid_password":"Parolă incorectă!","access_granted":"Acces permis! Folosește !commandadd pentru a adăuga comenzi sau !exit pentru a ieși.",
"no_file_selected":"Niciun fișier selectat!","command_added":"Comanda '{name}' a fost adăugată cu succes!",
"enter_command_name":"Introduceți numele noii comenzi:","welcome_admin":"Bine ai venit Admin!","enter_password":"Introduceți parola/admin license: ",
"language_changed":"Limba a fost schimbată cu succes!","categories":{"System":"Comenzi Sistem","Utilities":"Utilitare","Apps":"Aplicații"}},
"DE":{"select_language":"Wähle deine Sprache: 1-English 2-Romana 3-Deutsch 4-Español > ",
"command_not_found":"Befehl existiert nicht.","help_text":"Verfügbare Befehle: help, admin, exit, cls, !changelanguage",
"invalid_password":"Ungültiges Passwort!","access_granted":"Zugriff gewährt! Verwenden Sie !commandadd, um Befehle hinzuzufügen, oder !exit, um zu verlassen.",
"no_file_selected":"Keine Datei ausgewählt!","command_added":"Befehl '{name}' erfolgreich hinzugefügt!","enter_command_name":"Geben Sie den Namen des neuen Befehls ein:",
"welcome_admin":"Willkommen Admin!","enter_password":"Bitte geben Sie Ihr Admin-Passwort/Lizenz ein: ","language_changed":"Sprache erfolgreich geändert!",
"categories":{"System":"System Befehle","Utilities":"Dienstprogramme","Apps":"Anwendungen"}},
"ES":{"select_language":"Selecciona tu idioma: 1-English 2-Romana 3-Deutsch 4-Español > ",
"command_not_found":"Comando no existe.","help_text":"Comandos disponibles: help, admin, exit, cls, !changelanguage",
"invalid_password":"Contraseña incorrecta!","access_granted":"Acceso concedido! Usa !commandadd para agregar comandos o !exit para salir.",
"no_file_selected":"No se seleccionó ningún archivo!","command_added":"Comando '{name}' agregado correctamente!",
"enter_command_name":"Ingrese el nombre del nuevo comando:","welcome_admin":"¡Bienvenido Admin!","enter_password":"Ingrese su contraseña/licencia de admin: ",
"language_changed":"¡Idioma cambiado correctamente!","categories":{"System":"Comandos del Sistema","Utilities":"Utilidades","Apps":"Aplicaciones"}}}

def translate(key):
    return translations[LANG].get(key,key)

def save_config():
    with open(CONFIG_FILE,"w") as f:
        json.dump({"language": LANG},f)

def select_language():
    global LANG
    choice=input(translations["EN"]["select_language"]).strip()
    if choice=="1": LANG="EN"
    elif choice=="2": LANG="RO"
    elif choice=="3": LANG="DE"
    elif choice=="4": LANG="ES"
    else: LANG="EN"
    save_config()

def change_language():
    select_language()
    print(translate("language_changed"))

def clear():
    os.system("cls")

def run_dynamic_command(name):
    try:
        if name=="change_wallpaper":
            root=tk.Tk()
            root.withdraw()
            file_path=filedialog.askopenfilename(filetypes=[("Image files","*.jpg;*.jpeg;*.png")])
            if file_path:
                ctypes.windll.user32.SystemParametersInfoW(20,0,file_path,3)
                print("Wallpaper changed!")
        elif name=="open_settings": os.system("start ms-settings:")
        elif name=="open_explorer": os.system("start explorer")
        elif name=="open_notepad": os.system("notepad")
        elif name=="open_calc": os.system("calc")
        elif name in ["shutdown_pc","restart_pc","sleep_pc","lock_pc","logoff_pc",
                      "taskmgr","cmd","powershell","controlpanel","device_manager","msconfig","regedit",
                      "clear_temp","open_temp","ipconfig","ping_google","wifi_list",
                      "volume_mute","volume_max","open_msstore","open_calendar","open_camera","open_mail","open_maps"]:
            os.system(COMMANDS[name])
        elif name in COMMANDS and isinstance(COMMANDS[name],dict) and "path" in COMMANDS[name]:
            os.startfile(COMMANDS[name]["path"])
        else:
            print(translate("command_not_found"))
    except Exception as e:
        print(f"Eroare: {e}")

def open_admin_panel():
    os.system("color E")
    clear()
    print("        ___")
    print("       (•  •)   🍋")
    print("       (    )  ----------------------")
    print("        '--'   "+translate("welcome_admin")+"\n")
    pwd=input(translate("enter_password")).strip()
    if pwd!=ADMIN_PASSWORD:
        print(translate("invalid_password"))
        input("Press Enter to continue...")
        return
    print(translate("access_granted"))
    while True:
        cmd=input("[ADMIN] > ").strip()
        if cmd=="!exit": break
        elif cmd=="!commandadd":
            root=tk.Tk()
            root.withdraw()
            file_path=filedialog.askopenfilename(title="Select file", filetypes=[("Executables","*.exe")])
            if not file_path:
                print(translate("no_file_selected"))
                continue
            new_name=input(translate("enter_command_name")).strip()
            if new_name=="": continue
            COMMANDS[new_name]={"path":file_path}
            with open(COMMANDS_FILE,"w") as f:
                json.dump(COMMANDS,f,indent=4)
            print(translate("command_added").replace("{name}",new_name))
        else:
            print("!commandadd, !exit")


def main():
    os.system("color E")
    clear()
    print("© Hecker Commits™ . All rights served.\n")
    print("=== EasyPC Manager Terminal ===")
    print("Type 'help' to see available commands.\n")
    while True:
        user_input=input("> ").strip()
        if user_input.lower()=="exit": break
        elif user_input.lower()=="help":
            cats=translations[LANG]["categories"]
            print(translate("help_text"))
            print(f"\n{cats['System']}:")
            for cmd in ["shutdown_pc","restart_pc","sleep_pc","lock_pc","logoff_pc","taskmgr","cmd","powershell","controlpanel","device_manager","msconfig","regedit"]:
                print(f"- {cmd}")
            print(f"\n{cats['Utilities']}:")
            for cmd in ["clear_temp","open_temp","ipconfig","ping_google","wifi_list","volume_mute","volume_max"]:
                print(f"- {cmd}")
            print(f"\n{cats['Apps']}:")
            for cmd in ["open_settings","open_explorer","open_notepad","change_wallpaper","open_calc","open_msstore","open_calendar","open_camera","open_mail","open_maps"]:
                print(f"- {cmd}")
        elif user_input.lower()=="cls": clear()
        elif user_input.lower()=="admin": open_admin_panel(); clear()
        elif user_input.lower()=="!changelanguage": change_language()
        elif user_input in COMMANDS: run_dynamic_command(user_input)
        else: print(translate("command_not_found"))
    input("Press Enter to close...")

if __name__=="__main__":
    main()

    # bro why are u reading this WHOLE crappy thing bruh..
    # bro idk why but yh
    # ayo maybe you wanna find the password from the admin, idk why.. BUT YEAH! Ok the password is: password (but it doesn't work cause I was to lazy to script a scene where you put that password)

    ### IF YOU REALLY WANNA THE REAL PASSWORD FOR ADMIN JUST GO IN GITHUB AND LOOK IN DESCRIPTION FOR IT OK? cya
